<?php

const HOST = '103.97.126.29';
const DBNAME = 'ywzxbnyj_tea';
const USERNAME = 'ywzxbnyj_tea';
const PASSWORD = 'MY4qW8q7VHeRvPFUvGQS';

// const HOST = 'localhost';
// const DBNAME = 'tea';
// const USERNAME = 'root';
// const PASSWORD = '';