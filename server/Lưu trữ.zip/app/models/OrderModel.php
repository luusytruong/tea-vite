<?php

class OrderModel extends Model
{
    
}